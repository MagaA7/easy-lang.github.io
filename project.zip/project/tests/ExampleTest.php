<?php
use PHPUnit\Framework\TestCase;

class ExampleTest extends TestCase
{
    public function testTrueAssertsToTrue()
    {
        $this->assertTrue(true);
    }
}
